import { Component } from '@angular/core';

@Component({
  selector: 'app-nosotros',
  imports: [],
  templateUrl: './nosotros.html',
  styleUrl: './nosotros.css',
})
<<<<<<< HEAD
export class Nosotros {
=======
export class NosotrosComponent {
>>>>>>> ce174c7 (Subiendo proyecto EXTINTORES Angular)

}
