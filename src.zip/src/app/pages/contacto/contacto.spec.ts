import { ComponentFixture, TestBed } from '@angular/core/testing';
<<<<<<< HEAD

import { Contacto } from './contacto';

describe('Contacto', () => {
  let component: Contacto;
  let fixture: ComponentFixture<Contacto>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Contacto]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Contacto);
=======
import { ContactoComponent } from './contacto';

describe('ContactoComponent', () => {
  let component: ContactoComponent;
  let fixture: ComponentFixture<ContactoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContactoComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ContactoComponent);
>>>>>>> ce174c7 (Subiendo proyecto EXTINTORES Angular)
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
<<<<<<< HEAD
});
=======
});
>>>>>>> ce174c7 (Subiendo proyecto EXTINTORES Angular)
