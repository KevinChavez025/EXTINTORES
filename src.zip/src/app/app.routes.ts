import { Routes } from '@angular/router';
<<<<<<< HEAD

import { Home } from './pages/home/home';
import { Nosotros } from './pages/nosotros/nosotros';
import { Servicios } from './pages/servicios/servicios';
import { Productos } from './pages/productos/productos';
import { Contacto } from './pages/contacto/contacto';

export const routes: Routes = [
  { path: 'home', component: Home },
  { path: 'nosotros', component: Nosotros},
  { path: 'servicios', component: Servicios},
  { path: 'productos', component: Productos },
  { path: 'contacto', component: Contacto },
  { path: '', redirectTo: 'home', pathMatch: 'full' }, 
]
=======
import { HomeComponent } from './pages/home/home';
import { NosotrosComponent } from './pages/nosotros/nosotros';
import { ServiciosComponent } from './pages/servicios/servicios';
import { ProductosComponent } from './pages/productos/productos';
import { ContactoComponent } from './pages/contacto/contacto';
import { ProductoDetalleComponent } from './pages/producto-detalle/producto-detalle';  

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'nosotros', component: NosotrosComponent },
  { path: 'servicios', component: ServiciosComponent },
  { path: 'productos', component: ProductosComponent },
  { path: 'producto-detalle/:id', component: ProductoDetalleComponent },
  { path: 'contacto', component: ContactoComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];
>>>>>>> ce174c7 (Subiendo proyecto EXTINTORES Angular)
